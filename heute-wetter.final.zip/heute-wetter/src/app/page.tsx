// src/app/page.tsx
// Homepage — Server component
// Defaults to Berlin. Uses ISR (revalidate every 30 min).
// SEO: schema, OG tags, H1 unique content

import type { Metadata } from 'next';
import Link from 'next/link';
import { fetchWeather } from '@/lib/weather';
import { CITIES, TOP_CITIES } from '@/lib/cities';
import { WeatherHero } from '@/components/WeatherHero';
import { HourlyForecast } from '@/components/HourlyForecast';
import { DailyForecast } from '@/components/DailyForecast';
import { WeatherDetails } from '@/components/WeatherDetails';

export const revalidate = 1800; // 30 minutes ISR

export const metadata: Metadata = {
  title: 'Heute Wetter – Aktuelles Wetter für Deutschland',
  description:
    'Aktuelle Wetterdaten für ganz Deutschland. Temperatur, Regen, Wind und 7-Tage-Vorhersage für Berlin, Hamburg, München und alle anderen Städte.',
  alternates: { canonical: 'https://heute-wetter.de' },
};

// Homepage schema markup
function HomepageSchema() {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: 'Heute Wetter',
    url: 'https://heute-wetter.de',
    description: 'Aktuelles Wetter für alle deutschen Städte',
    potentialAction: {
      '@type': 'SearchAction',
      target: 'https://heute-wetter.de/wetter/{search_term_string}',
      'query-input': 'required name=search_term_string',
    },
  };
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  );
}

export default async function HomePage() {
  // Default city: Berlin
  const defaultCity = CITIES.find((c) => c.slug === 'berlin')!;

  let weather;
  let fetchError = false;
  try {
    weather = await fetchWeather(defaultCity.lat, defaultCity.lon, defaultCity.timezone);
  } catch {
    fetchError = true;
  }

  return (
    <>
      <HomepageSchema />

      {/* Hero — current weather */}
      {weather && !fetchError ? (
        <WeatherHero city={defaultCity} weather={weather.current} />
      ) : (
        <div className="hero" style={{ textAlign: 'center', padding: '4rem 1rem' }}>
          <p style={{ color: 'var(--text-secondary)' }}>
            Wetterdaten konnten nicht geladen werden. Bitte versuche es später erneut.
          </p>
        </div>
      )}

      <div className="container" style={{ paddingTop: '2rem' }}>
        {weather && !fetchError && (
          <>
            {/* Hourly */}
            <section aria-label="Stündliche Vorhersage" className="mb-8">
              <p className="section-title">Stundenweise</p>
              <HourlyForecast hours={weather.hourly} />
            </section>

            {/* Details grid */}
            <section aria-label="Wetterdetails" className="mb-8">
              <p className="section-title">Details</p>
              <WeatherDetails current={weather.current} />
            </section>

            {/* 7-day */}
            <section aria-label="7-Tage-Vorhersage" className="mb-10">
              <p className="section-title">7-Tage-Vorhersage</p>
              <DailyForecast days={weather.daily} />
            </section>
          </>
        )}

        {/* SEO: unique editorial content */}
        <section aria-label="Städte-Übersicht" className="mb-10">
          <p className="section-title">Wetter nach Städten</p>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.3rem', marginBottom: '1rem' }}>
            Wetter in deutschen Großstädten
          </h2>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: '1.25rem', maxWidth: '640px', lineHeight: '1.7' }}>
            Aktuelles Wetter und 7-Tage-Vorhersage für die größten Städte Deutschlands.
            Jede Seite liefert Echtzeit-Daten von Open-Meteo – kostenlos, ohne Werbung und mobil optimiert.
          </p>
          <nav aria-label="Städte-Navigation">
            <div className="city-link-grid">
              {CITIES.map((city) => (
                <Link
                  key={city.slug}
                  href={`/wetter/${city.slug}`}
                  className="city-link-pill"
                  title={`Wetter ${city.name}`}
                >
                  📍 {city.name}
                </Link>
              ))}
            </div>
          </nav>
        </section>

        {/* About section — good for SEO */}
        <section className="card mb-10" aria-label="Über Heute Wetter">
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.15rem', marginBottom: '0.75rem' }}>
            Zuverlässige Wetterdaten für ganz Deutschland
          </h2>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem', lineHeight: '1.8', marginBottom: '0.75rem' }}>
            Heute Wetter nutzt die offene Wetter-API von{' '}
            <a href="https://open-meteo.com" target="_blank" rel="noopener noreferrer" style={{ color: 'var(--accent)' }}>
              Open-Meteo
            </a>{' '}
            – einem europäischen Wetterdienst, der auf Hochleistungs-Wettermodellen basiert.
            Die Daten werden stündlich aktualisiert und bieten minutengenaue Vorhersagen für Temperatur,
            Niederschlag, Windgeschwindigkeit, UV-Index und vieles mehr.
          </p>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem', lineHeight: '1.8' }}>
            Unsere Plattform ist vollständig kostenlos, ohne Registrierung und ohne Werbung.
            Einfach eine Stadt auswählen und das aktuelle Wetter sofort sehen.
          </p>
        </section>
      </div>
    </>
  );
}
